import React from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux"; // Correct import for useDispatch
import { addToCart } from '../../store/cartSlice'; 

function Card({ item }) {
  const { title, description, price, id, imageUrl } = item;
  const navigate = useNavigate();
  const dispatch = useDispatch(); // Define dispatch

  const handleClick = () => {
    navigate(`detail/${id}`);
  };
  const handleAddToCart = () => {
    dispatch(addToCart(item)); // Dispatch addToCart action with the item
  };


  return (
    <div className="card" style={{ width: "18rem", cursor: "pointer" }}>
      <img
        src={imageUrl || "placeholder.jpg"} // Use a placeholder image if imageUrl is not provided
        className="card-img-top"
        alt={title || "Item"} // Use a fallback alt text if title is not provided
        style={{ height: "200px", width: "100%", objectFit: "cover" }}
        onClick={handleClick}
      />
      <div className="card-body">
        <img
          className="hearts"
          src="https://www.iconpacks.net/icons/2/free-heart-icon-3512-thumb.png"
          alt="Heart icon"
        />
        <h5 className="card-title">{title || "No Title"}</h5>
        <p className="card-text">{description || "No Description"}</p>
        <p>Price: {price || "N/A"}</p>
        
        <button onClick={() => handleAddToCart(item)}>Add to Cart</button>
      </div>
    </div>
  );
}

export default Card;
