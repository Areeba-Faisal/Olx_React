import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut  } from "firebase/auth";
import { getFirestore,collection, addDoc, getDocs,deleteDoc, doc } from "firebase/firestore";
import { initializeApp } from "firebase/app";
import { useNavigate } from "react-router-dom";
import { getDownloadURL, getStorage, ref, uploadBytes } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyALGRXwPUowdMepJP5eKJ0q2m_uKE01yeM",
  authDomain: "olx-auth-c0685.firebaseapp.com",
  projectId: "olx-auth-c0685",
  storageBucket: "olx-auth-c0685.appspot.com",
  messagingSenderId: "736098877080",
  appId: "1:736098877080:web:3dd43e76c3280fdaf8daed",
  measurementId: "G-MDV8EKQYR3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export async function register(userInfo) {
   const { email, password, fullName, age } = userInfo;
  try {
    console.log(email, age, fullName);
    await addDoc(collection(db, "users"), {
      email,
      fullName,
      age,
    });
    await createUserWithEmailAndPassword(auth, email, password);
    alert("User Created");
    return true;
  } catch (error) {
    alert("err:",error.message);
  }
}

export async function login(userInfo) {
  const { email, password, age } = userInfo;
  console.log(email, password);
  try {
    await signInWithEmailAndPassword(auth, email, password);
    alert("successfully login");
  return true;
  } catch (error) {
    alert(error.message);
  }
}

export async function addItem(userInfo) {
  try {
    const { brand, title, description, category, price, images } = userInfo;
    const imageArray = Array.from(images); // no need to convert the first element of images to an array

    const arr = [];

    // Use Promise.all to wait for all uploads to complete
    await Promise.all(imageArray.map(async (file) => {
      const storageRef = ref(storage, `images/${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      console.log(`File ${file.name} uploaded. Download URL: ${downloadURL}`);
      arr.push(downloadURL);
    }));

    console.log('All files uploaded. Download URLs:', arr);

    await addDoc(collection(db, "products"), {
      title,
      description,
      category,
      price,
      brand,
      ImageURL: arr,
    });

    console.log("Ad posted successfully");
    alert("Ad posted successfully!");
  } catch (error) {
    console.error("Error posting ad:", error);
    alert(error.message);
  }
}

export async function getAds() {
  const querySnapshot = await getDocs(collection(db, 'products'));
  const ads=[]
  querySnapshot.forEach((doc) => {
    const ad = doc.data() //{title ,description, price, imageUrl}
    ad.id = doc.id //{id,title ,description, price, imageUrl}

    ads.push(ad)
  })

  return ads
}

export const getApiData = async () => {
  const postAds =[]
  const querySnapshot = await getDocs(collection(db, "user"));
  querySnapshot.forEach((doc) => {
    // console.log(doc.id, " => ", doc.data());
    const dat = doc.data()
    dat.id = doc.id
    postAds.push(dat)
  });
  return postAds

}

export const ProfileData = async () => {
  const postAds = []
  const querySnapshot = await getDocs(collection(db, "users"));
  querySnapshot.forEach((doc) => {
    // console.log(doc.id, " => ", doc.data());
    const dat = doc.data()
    dat.id = doc.id
    postAds.push(dat)
  });
  return postAds
}
ProfileData()

export async function updateData (e, img) {
  const userd = e[0]
  try{
    console.log(userd)
    const storageRef = ref(storage, `profile image/${img.name}`);
    await uploadBytes(storageRef, img);
    const Url = await getDownloadURL(storageRef)
    console.log(Url);
    await addDoc(collection(db, "users"), {
      fullName:userd.fullName,
      age:userd.age,
      email:userd.email,
      image:Url
    });
    const ver = await deleteDoc(doc(db,"users", userd.id))
    console.log(ver)
    
    alert("Profile is Updated")
  }catch(e) {
    console.log(e.message)
  }
}

export async function getForm() {
  const querySnapshot = await getDocs(collection(db, "form"));
  const form = [];
  querySnapshot.forEach((doc) => {
    const userInfo = doc.data();
    userInfo.id = doc.id;

    form.push(userInfo);
  });

  return form;
}
