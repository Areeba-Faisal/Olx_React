import { createBrowserRouter,RouterProvider,Outlet, useNavigate} from "react-router-dom";
import Dashboard from "../view/Dashboard";
import Detail from "../view/Dashboard/detail";
import Card from "../components/Card";
import Signup from "../view/signup";
import Login from "../view/login";
import Sellitem from "../view/sellItem";
import Header from "../view/Dashboard/header";
import Profile from "../view/profile";
import { onAuthStateChanged } from "firebase/auth";
import {auth} from "./firebase"
import { useEffect, useState } from "react";
import Footer from "../view/footer";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout/>,
    children:[
      
      {
        path: "/",
        element: <Dashboard/>,
      },
      {
        path: "/Card",
        element: <Card/>,
      },
      {
        path: "/detail/:adId",
        element: <Detail/>,
      },
     
    ]
  },
  {
    path:"/sellItem",
    element:<Sellitem/>
  },
  {
    path: "/profile",
    element: <Profile/>,
  },

  {
    path: "/login",
    element: <Login/>,
  },
  {
    path: "/signup",
    element: <Signup/>,
  },
  ]);

  function Layout () {
    const navigate = useNavigate();
    const [user, setUser] = useState()

    useEffect(() => {
      onAuthStateChanged(auth, (user) => {
        if (user) {
      // console.log("user:",user)
        
          const uid = user;
          setUser(user);
          
        } else {
          setUser(null);
        
        }
    });
},[]);

    useEffect (() => {
      const {pathname} = window.location; 
      if (user) {
        if (pathname === '/login' || pathname === "/signup") {
          navigate("/");
        }
      } else {
        if(!user){
          if (pathname === "/sellItem"){
            navigate ('/login');
          }


        }
      }
    }, [window.location.pathname, user]);

    return (
      <div>
        <Header/>
        <Outlet/>
        <Footer/>
      </div>
    )
  }
  
  function Router () {
    return  <RouterProvider router={router} />
  }

export default Router;