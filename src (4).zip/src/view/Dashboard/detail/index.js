import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import UserProfile from "../../userprofile";
import LocationBox from "../../locationbox";
import { doc, getDoc, getFirestore } from "firebase/firestore";

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

// import required modules
import { Navigation, Pagination } from 'swiper/modules';

function Detail() {
  const db = getFirestore();
  const { adId } = useParams();
  const [productDetail, setProductDetail] = useState(null);

  useEffect(() => {
    // getProductDetail();
  }, [adId, db]);

  console.log("adId",adId);


  useEffect(() => {
    
    const getProductDetail = async () => {
      console.log('Id:', adId);
      const docRef = doc(db, "products", adId);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        console.log("Document data:", docSnap.data());
        setProductDetail(docSnap.data())
      } else {
        // docSnap.data() will be undefined in this case
        console.log("No such document!");
      }
    };
  getProductDetail();
}, [adId]); 

  if (!productDetail) {
    return <div>Loading...</div>;
  }

  const { title, description, price, category, images } = productDetail;

  return (
    <div className="detail">

      {/* Content */}
      {/* <span className="after-nav">
        <b>All Categories</b> MobilePhones Cars Motorcycles Houses Videos-Audios Tablets Land$Plot
      </span>
      <br /><br /><br /> */}
      <div className="add">
        <img src="https://images.olx.com.pk/thumbnails/423979386-800x600.webp" alt="Ad" />
      </div>
      <br /><br />
      <img className="share" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT44kXJPkTXDld4n39CaqVeKbQDbU9DEx6yxg&usqp=CAU" alt="Share" />
      <img className="heart" src="https://www.iconpacks.net/icons/2/free-heart-icon-3512-thumb.png" alt="Heart" />
      <img className="flag" src="https://cdn-icons-png.flaticon.com/512/6000/6000197.png" alt="Flag" />
      <div>
        <Swiper
          navigation={true}
          pagination={true}
          modules={[Navigation, Pagination]}
          className="mySwiper"
        >
   {productDetail.ImageURL.map((item, index) => (
  <SwiperSlide style={{ width: "300px", height: "700px" }} key={index}>
    <img src={item} alt={`Slide ${index}`} />
  </SwiperSlide>
))}


        </Swiper>
      </div>
      <div className="details">
        <h2 className="d-t">{productDetail.title}</h2>
        <p className="d-p">Price: {productDetail.price}</p>
        <p className="d-c">Category: {productDetail.category}</p>
        <p className="d-d">Description: {productDetail.description}</p>
      </div>
      <p className="id">AD ID 1082671889</p>
      <p className="report">Report this ad</p>
      <div className="addd">
        <img className="ad-img" src="https://tpc.googlesyndication.com/simgad/6265995730542311294" alt="Advertisement" />
      </div>
      <UserProfile className="profile" />
      <LocationBox />
      <br /><br />
    </div>
  );
}

export default Detail;
