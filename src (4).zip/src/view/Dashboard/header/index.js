import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import { getAuth, onAuthStateChanged , signOut } from "firebase/auth";
import "./index.css"
import { ProfileData } from "../../../config/firebase";
import { useDispatch, useSelector } from 'react-redux'
import {addToCart} from "../../../store/cartSlice"
function Header () {
  const navigate = useNavigate();
  const [user, setUser] = useState(null)
  const [userData, setUserData] = useState(null)
  // const [ProfileData, setProfileData] = useState(null)
  const [image, setImage] =useState('null')
  const auth = getAuth();

  const [toggle, setToggle] = useState(false)
  const dispatch = useDispatch()
  const cart = useSelector(state => state.cartReducer.cart)


  useEffect(() => {
    const auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      if (user) {
    console.log("user:",user)
      
        const uid = user;
        setUser(uid.email);
        
      } else {
        setUser(null);
     setImage("null")
      
      }
  });
},[]);

// useEffect(() => {
//   fetchData();

//   async function fetchData() {
//     try {
//       const pdata = await ProfileData();
//       console.log('pdata:', pdata);

//       const foundItem = pdata.filter((res) => res.email === user);

//       if (foundItem.length > 0) {
//         console.log("Element found:", foundItem);
//         setUserData((prevUserData) => {
//           console.log("Previous userdata:", prevUserData);
//           return foundItem;
//         });

//         if (foundItem[0]) {
      
//           setImage(foundItem[0].image);
//         } else {
//           setImage(null);
//         }
//       } else {
//         console.log("Element not found");
//         setImage(null);
//       }
//     } catch (e) {
//       alert(e.message);
//     }
//   }
// }, [user]);





 async function logout() {
  const auth = getAuth();
  await signOut(auth)
  setUser(null)
  setImage('null')
  console.log("logged out") }

  const handleAddToCart = (item) => {
    dispatch(addToCart(item));
  };

return (
<div className="products">
<div className="header">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand logo" href="#">
  <img src="https://www.logosvgpng.com/wp-content/uploads/2020/10/olx-logo-vector.png" />
</a>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
  <ul class="navbar-nav mr-auto">

      <div class="input-group input-group-lg location mr-4">
          <input type="text" class="form-control" placeholder="Pakistan" />
          <div class="input-group-btn">
         
              <img class="ico" width={80} src="https://www.clker.com/cliparts/w/r/Q/0/x/D/search-icon-light-grey-hi.png" alt="" />
          </div>
      </div>

      <div class="input-group input-group-lg search">

          <input type="text" class="form-control" placeholder="Find Cars, Mobile Phones and more..." />
          <div class="input-group-btn">
          <img class="icon" width={80} src="https://www.clker.com/cliparts/w/r/Q/0/x/D/search-icon-light-grey-hi.png" alt="" />
          </div>
      </div>
  </ul>

<div className="input-login"> 
          { user ?
            <div className="header-profile_img">
              <img className="header-img" src={image == "null" ? "https://www.olx.com.pk/assets/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png" :`${image}` }/>
               </div>
            :
            <a href="#" onClick={() => navigate("/login")}> Login </a>
          }
             { user ?
          <div className="logout-section">
            <div className="logout-sec_profile">
              <div className="sec-prof-main">
              <div className="sec-prof-img">
            <img className="header-img" src={image == "null" ? "https://www.olx.com.pk/assets/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png" :`${image}` }/>
              </div>
              <div className="prof-sec-data">
                <p>Hi,</p>
                <h4>{user}</h4>
                <p><a href="#" onClick={() => navigate("/profile")}>View and edit your profile</a></p>
              </div>
              </div>
            </div>
            <hr class="hr bg-black" />
          <a href="#" onClick={logout}>Logout</a>
          </div>
           : ""  }
          </div>

          <img className="cart-img" style={{ width:"20", borderRadius:"100%"}}
   src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9395PGIlJyVM5ZD7SFPwNb7IiPXHbCs9lZ8Z3k2qz&s  "
        ></img>

<div onClick={() => setToggle(!toggle)}>
           {/* <img 
            width="6"
            height="80"
  
          /> */}
            {cart.length}
        </div>

        {toggle && (
  <div>
    {cart.map((item, index) => (
      <div key={index}>
        <h3>{item.title} - Rs. {item.amount}</h3>
        <button onClick={() => handleAddToCart(item)}>Add to Cart</button>
      </div>
    ))}
  </div>
)}

      

<button className="my-2 my-sm-0 fas fa-plus sell" onClick={() => navigate("/sellItem")}> SELL</button>


</div>
</nav>
<br/> 
</div>
 <span class='after-nav'>
  <b>AllCategories </b>     MobilePhones       Cars       Motorcycles Houses       Videos-Audios       Tablets       Land$Plot
</span>
<br /><br /><br />

</div>
  )}

  export default Header;

