import React from "react";
import Card from "../../components/Card";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"; 
import {auth, getAds} from "../../config/firebase/index"
import { onAuthStateChanged } from "firebase/auth";
import Navbaar from "./navbar";

function Dashboard() {
  const navigate = useNavigate();
  const [Posts, setPosts] = useState([]);
  const [user, setUser] = useState(null)

  
  
  useEffect(() =>{
    onAuthStateChanged(auth,(user) => {
      if(user) {
        console.log(user)
        setUser(user)
      }else{
        setUser(null)
      }
    })
  }, [])

  useEffect(()=> {
    getProducts();
  }, [])


 const getProducts = async () => {
  const ads = await getAds()
  console.log('ads in component', ads)
  setPosts(ads)
 }

  if (!Posts.length) {
    return (
      <div>
        <img src="https://i.pinimg.com/originals/c7/e1/b7/c7e1b7b5753737039e1bdbda578132b8.gif" />
      </div>
    );
  }

  return (
    <div className="products">
      <Navbaar/>
      <div className="cards container mt-4">

        <div className="row row-cols-1 row-cols-md-3 g-4">
          {Posts.map((item) => {
            // const { title, price, description, id, thumbnail } = item;
            return (
              <div
              //  key={id}
                className="col">
                <Card className="card border" 
                // id={id} title={title} price={price} description={description} thumbnail={thumbnail}
                item={item} />
              </div>
            );
          })}
        </div>
      </div>
    </div>)}
export default Dashboard;
