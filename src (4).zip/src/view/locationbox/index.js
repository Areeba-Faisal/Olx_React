import React from "react";
// import { FaMapMarkerAlt } from "react-icons/fa"; // Import location icon from react-icons library
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const LocationBox = () => {
  return (
    <div className="location-box">
      <div className="location-container">
        <div>
          <p className="location-label">Location</p>
          {/* <FontAwesomeIcon icon="fa-regular fa-location-dot" /> */}
          <img className="l-img" src="https://static.vecteezy.com/system/resources/thumbnails/000/552/683/small/location_pin_002.jpg"/>
          <p className="location-info">DHA, Karachi</p>
        </div>
      </div>
    </div>
  );
};

export default LocationBox;
