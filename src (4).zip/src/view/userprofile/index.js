import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone, faComments } from '@fortawesome/free-solid-svg-icons'; // Import the specific icons you need

const UserProfile = () => {
  return (
    <div className="user-profile">
      {/* Profile Picture and Name */}
      <div className="profile-info">
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQIAxBfbt0cCem8CRlimPOmJlDtDlU8loi4Osj1bKVhwQ&s"
          alt="Profile"
          className="profile-pic"
        />
        <div className="profile-details">
          <p className="name">Areeba Faisal</p>
          <p className="names">Member since July 2023</p>
        </div>
      </div>

      {/* View Profile */}
      <div className="action-container">
        <p className="see">See Profile</p>
      </div><br/>

      {/* Show Phone Number */}
      <div className="action-container phone">
        <p className="pn">Show Phone Number</p>
        <FontAwesomeIcon icon={faPhone} className="icon" />
      </div>

      {/* Chat */} 
      <div className="action-container chat">
        <p className="chatt">Chat</p>
        <FontAwesomeIcon icon={faComments} className="icon" />
      </div>
    </div>
  );
};

export default UserProfile;
